#pragma once

namespace 
{
	const unsigned int GL_REVISION = 28434;
}
