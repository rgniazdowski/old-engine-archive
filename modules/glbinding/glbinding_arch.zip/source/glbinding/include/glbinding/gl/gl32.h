#pragma once

#include <glbinding/glbinding_api.h>

#include <glbinding/gl/nogl.h>

#include <glbinding/gl/extension.h>

#include <glbinding/gl/types.h>

#include <glbinding/gl/boolean.h>

#include <glbinding/gl/bitfield32.h>
#include <glbinding/gl/bitfield32ext.h>
#include <glbinding/gl/enum32.h>
#include <glbinding/gl/enum32ext.h>
#include <glbinding/gl/functions32.h>
#include <glbinding/gl/functions32ext.h>
