#pragma once

#include <glbinding/gl/nogl.h>
#include <glbinding/gl/types.h>

#include <glbinding/gl/enum.h>


namespace gl10
{

// import enums to namespace



} // namespace gl10
